package com.example.lab_ch5.controller

import com.example.lab_ch5.domain.Board
import org.springframework.beans.factory.annotation.Value
import org.springframework.stereotype.Controller
import org.springframework.ui.Model
import org.springframework.web.bind.annotation.ExceptionHandler
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.multipart.MultipartFile
import java.nio.file.Files
import java.nio.file.Paths

@Controller
@RequestMapping("/thymeleaf")
class ThymeleafBoardController {
    @Value("\${file.upload.path:./upload}")
    lateinit var uploadPath: String

    val boardList = mutableListOf<Board>()
    var seq = 0

    init {
        boardList.add(Board(++seq, "title1", "writer1", "content1"))
        boardList.add(Board(++seq, "title2", "writer2", "content2"))
    }

    @RequestMapping("/getBoardList")
    fun getBoardList(model: Model): String {

        model.addAttribute("boardList", boardList)
        return "thymeleaf/getBoardList"
    }

    @GetMapping("/insertBoard")
    fun insertBoardView(): String {
        return "thymeleaf/insertBoard"
    }
    @PostMapping("/insertBoard")
    fun insertBoard(board: Board, @RequestParam("uploadFile") file: MultipartFile?): String {

        file?.let {
            println("==>1")
            if(!file.isEmpty){
                println("==>2")
                try {
                    val filename = file.originalFilename ?: "unknown"
                    val dir = Paths.get(uploadPath)
                    if(!Files.exists(dir)){
                        Files.createDirectories(dir)
                    }
                    val filePath = dir.resolve(filename)
                    println("==>${filePath}")
                    file.transferTo(filePath.toFile())
                }catch (e: Exception){
                    println("upload fail: ${e.message}")
                }
            }
        }

        board.seq = ++seq
        boardList.add(board)
        return "forward:getBoardList"
    }

    @GetMapping("/getBoard")
    fun getBoard(@RequestParam seq: Int, model: Model): String {
        model.addAttribute("board", boardList.find { it.seq == seq })
        return "thymeleaf/getBoard"
    }

    @GetMapping("/updateBoard/{seq}")
    fun updateBoardView(@PathVariable seq: Int, model: Model): String {
        model.addAttribute("board", boardList.find { it.seq == seq })
        model.addAttribute("mode", "update")
        return "thymeleaf/insertBoard"
    }
    @PostMapping("/updateBoard/{seq}")
    fun updateBoard(@PathVariable seq: Int, board: Board): String {
        val index = boardList.indexOfFirst { it.seq == seq }
        boardList[index] = board
        return "redirect:/thymeleaf/getBoardList"
    }

    @PostMapping("/deleteBoard/{seq}")
    fun deleteBoard(@PathVariable seq: Int): String {
        boardList.removeIf { it.seq == seq }
        return "redirect:/thymeleaf/getBoardList"
    }
}
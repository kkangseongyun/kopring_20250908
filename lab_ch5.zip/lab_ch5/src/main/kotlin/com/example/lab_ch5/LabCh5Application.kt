package com.example.lab_ch5

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class LabCh5Application

fun main(args: Array<String>) {
	runApplication<LabCh5Application>(*args)
}

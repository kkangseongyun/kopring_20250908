package com.example.lab_ch5.controller

import com.example.lab_ch5.domain.Board
import org.springframework.stereotype.Controller
import org.springframework.ui.Model
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam

@Controller
class BoardController {
    val boardList = mutableListOf<Board>()
    var seq = 0

    init {
        boardList.add(Board(++seq, "title1", "writer1", "content1"))
        boardList.add(Board(++seq, "title2", "writer2", "content2"))
    }

    //url 조건만 명시했다.. method 는 명시하지 않았다.. 모든 method 에 실행된다..
    //다른 요청에서 forward 방식으로 목록을 띄우는 경우에도 실행되게 하고 싶어서.. 다른 곳의 요청이
    //post 방식일 수도 있어서..
    @RequestMapping("/getBoardList")
    fun getBoardList(model: Model): String {
        //결과 데이터를 jsp 에 전달해서.. jsp 에서 html 에 결과 데이터가 출력되게..
        //Model 이 View에 전달할 데이터를 담는 곳..
        model.addAttribute("boardList", boardList)
        return "getBoardList"//문자열 리턴이다. @ResponseBody 가 선언되지 않았다.. ViewResolver 동작한다
    }

    @GetMapping("/insertBoard")
    fun insertBoardView(): String {
        return "insertBoard"//글 입력을 위한 화면만 요청한 경우..
    }
    @PostMapping("/insertBoard")
    fun insertBoard(board: Board): String {
        board.seq = ++seq
        boardList.add(board)
        return "forward:getBoardList"//forward 방식으로 화면을 목록 화면으로..
    }

    @GetMapping("/getBoard")
    fun getBoard(@RequestParam seq: Int, model: Model): String {
        model.addAttribute("board", boardList.find { it.seq == seq })
        return "getBoard"
    }

    @GetMapping("/updateBoard/{seq}")
    fun updateBoardView(@PathVariable seq: Int, model: Model): String {
        model.addAttribute("board", boardList.find { it.seq == seq })
        model.addAttribute("mode", "update")
        return "insertBoard"
    }
    @PostMapping("/updateBoard/{seq}")
    fun updateBoard(@PathVariable seq: Int, board: Board): String {
        val index = boardList.indexOfFirst { it.seq == seq }
        boardList[index] = board
        return "redirect:/getBoardList"
    }

    @PostMapping("/deleteBoard/{seq}")
    fun deleteBoard(@PathVariable seq: Int): String {
        boardList.removeIf { it.seq == seq }
        return "redirect:/getBoardList"
    }
}
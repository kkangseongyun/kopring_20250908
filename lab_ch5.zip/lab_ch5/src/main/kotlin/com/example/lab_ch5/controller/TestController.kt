package com.example.lab_ch5.controller

import org.springframework.beans.factory.annotation.Autowired
import org.springframework.context.MessageSource
import org.springframework.http.HttpStatus
import org.springframework.stereotype.Controller
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.server.ResponseStatusException
import java.util.Locale

@Controller
class TestController {

    @GetMapping("/error-404")
    fun test404(): String {
        throw ResponseStatusException(HttpStatus.NOT_FOUND, "페이지 없다")
    }

    @GetMapping("/error-500")
    fun test500(): String {
        throw RuntimeException("서버 에러..")
    }

    @Autowired
    lateinit var messageSource: MessageSource
    @GetMapping("/message")
    fun message(locale: Locale): String {
        val message = messageSource.getMessage(
            "welcome.message", null, locale)
        println("==>$message")
        return "thymeleaf/message"
    }
}
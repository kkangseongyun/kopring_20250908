package com.example.lab_ch6.persistence

import com.example.lab_ch6.domain.Board
import org.apache.ibatis.annotations.Param
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.data.jpa.repository.Query

//JPQL을 이용한 검색..
//JPQL은 함수명은 의미가 없다. 개발자 임의 함수..
//QueryMethod 규칙으로 만든 함수에 JPQL을 같이 추가하면 JPQL이 우선순위가 높다..
interface JPQLSearchRepository: JpaRepository<Board, Int> {
    //작성자 검색
    @Query("SELECT b FROM Board b WHERE b.writer = :keyword")
    fun findBoardByWriter(@Param("keyword") keyword: String): List<Board>

    //제목 검색.. 제네릭의 Board 는 생략 가능
    @Query("SELECT b FROM Board b WHERE b.title LIKE %:keyword% ORDER BY b.seq DESC")
    fun findByTitleContainingOrderBySeqDesc(@Param("keyword") keyword: String): List<Board>

    //본문 검색
    @Query("SELECT b FROM Board b WHERE b.content LIKE %:keyword%")
    fun findByContentContaining(@Param("keyword") keyword: String): List<Board>

    //두 컬럼.. 제목, 본문 검색..
    @Query("SELECT b FROM Board b WHERE b.title LIKE %:title% OR b.content LIKE %:content%")
    fun findByTitleContainingOrContentContaining(
        @Param("title") title: String,
        @Param("content") content: String):
            List<Board>
}
package com.example.lab_ch6.persistence

import com.example.lab_ch6.domain.Board
import org.springframework.data.jpa.repository.JpaRepository

//제네릭 타입 꼭 명시되어야 한다.
//Entity class - id 타입
//하나의 JpaRepository에서 여러 Entity 걸수는 없다..
//JpaRepository 를 상속 받는 것만으로.. CRUD 를 위한 기본 함수가 내장된다..
//save(), findAll(), count(), delete()
//원한다면 이 인터페이스에 개발자 함수 추가해서. dbms 되게 할 수도 있다.. - QueryMethod
interface JPABoardRepository: JpaRepository<Board, Int>
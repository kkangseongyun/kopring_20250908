package com.example.lab_ch6.persistence

import com.example.lab_ch6.domain.Board
import org.springframework.data.jpa.repository.JpaRepository

//QueryMethod
interface QueryMethodSearchRepository: JpaRepository<Board, Int> {
    //작성자 검색
    fun findBoardByWriter(keyword: String): List<Board>

    //제목 검색.. 제네릭의 Board 는 생략 가능
    fun findByTitleContainingOrderBySeqDesc(keyword: String): List<Board>

    //본문 검색
    fun findByContentContaining(keywoard: String): List<Board>

    //두 컬럼.. 제목, 본문 검색..
    fun findByTitleContainingOrContentContaining(title: String, content: String):
            List<Board>
}
package com.example.lab_ch6.service

import com.example.lab_ch6.domain.Board
import com.example.lab_ch6.persistence.JPABoardRepository
import jakarta.transaction.Transactional
import org.springframework.stereotype.Service

@Service
class JPABoardService(
    private val boardRepository: JPABoardRepository
) {
    fun getBoard(seq: Int): Board {
        return boardRepository.findById(seq)
            .orElseThrow {
                RuntimeException("board not found")
            }
    }
    fun getBoardList(): List<Board>{
        return boardRepository.findAll()
    }
    fun insertBoard(board: Board){
        boardRepository.save(board)
    }
    //매개변수로 전달된 데이터가 이전에.. 데이터베이스에서 획득한 데이터라고 하더라도..
    //매개변수로 전달된 수정된 데이터를 직접  update 하려면..
    //매개변수로 전달된 엔터티 객체가 jpa context에 관리상태야 가능하다..
    //아래처럼 새로 select 해서.. select 한 엔터티를 업데이트 되게 하는 것이 권장방법이다.
    fun updateBoard(seq: Int, board: Board){
        val existingBoard = boardRepository.findById(seq)
            .orElseThrow {
                RuntimeException("board not found")
            }
        existingBoard.title = board.title
        existingBoard.writer = board.writer
        existingBoard.content = board.content
        existingBoard.cnt = board.cnt

        boardRepository.save(existingBoard)
    }

    @Transactional
    fun deleteBoard(seq: Int){
        //jpa context에 유지되는 엔티티만 삭제가 가능해서..
        val board = boardRepository.findById(seq)
            .orElseThrow {
                RuntimeException("board not found")
            }
        boardRepository.delete(board)
        boardRepository.flush()
    }
}
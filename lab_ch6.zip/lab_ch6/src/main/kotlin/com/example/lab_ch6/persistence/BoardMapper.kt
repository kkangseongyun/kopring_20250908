package com.example.lab_ch6.persistence

import com.example.lab_ch6.domain.Board
import org.apache.ibatis.annotations.Mapper

@Mapper
interface BoardMapper {
    fun insertBoard(board: Board)
    fun updateBoard(seq: Int, board: Board)
    fun deleteBoard(seq: Int)
    fun getBoardList(): List<Board>
    fun getBoard(seq: Int): Board
}
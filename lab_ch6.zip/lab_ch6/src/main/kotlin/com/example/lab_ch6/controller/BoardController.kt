package com.example.lab_ch6.controller


import com.example.lab_ch6.domain.Board
import com.example.lab_ch6.service.BoardSearchService
import com.example.lab_ch6.service.JPABoardService
import com.example.lab_ch6.service.MyBatisBoardService
import org.springframework.beans.factory.annotation.Value
import org.springframework.stereotype.Controller
import org.springframework.ui.Model
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.multipart.MultipartFile
import java.nio.file.Files
import java.nio.file.Paths

@Controller
class BoardController(
//    private val boardService: MyBatisBoardService
    private val boardService: JPABoardService,
    private val searchService: BoardSearchService
) {

    @Value("\${file.upload.path:./uploads}")
    private lateinit var uploadPath: String


    @RequestMapping("/getBoardList")
    fun getBoardList(model: Model): String{

        val boardList = boardService.getBoardList()
        model.addAttribute("boardList", boardList)

        println("==> ${boardList.size}")

        return "thymeleaf/listBoard"
    }

    @GetMapping("/insertBoard")
    fun insertBoardView(): String {
        return "thymeleaf/insertBoard"
    }

    @PostMapping("/insertBoard")
    fun insertBoard(board: Board, @RequestParam("uploadFile") file: MultipartFile?): String {

        file?.let {
            if (!file.isEmpty) {
                try {
                    val filename = file.originalFilename ?: "unknown"

                    val uploadDir = Paths.get(uploadPath)
                    if (!Files.exists(uploadDir)) {
                        Files.createDirectories(uploadDir)
                    }

                    val filePath = uploadDir.resolve(filename)
                    file.transferTo(filePath.toFile())

                    "파일 업로드 성공: $filename (저장 위치: $filePath)"
                } catch (e: Exception) {
                    println("업로드 실패: ${e.message}")
                }
            }

        }

        boardService.insertBoard(board)

        return "forward:getBoardList"
    }

    @GetMapping("/getBoard")
    fun getBoard(@RequestParam seq: Int, model: Model): String{

        model.addAttribute("board", boardService.getBoard(seq))

        return "thymeleaf/detailBoard"
    }

    @GetMapping("/updateBoard/{seq}")
    fun updateBoardView(@PathVariable seq: Int, model: Model): String {

        model.addAttribute("board", boardService.getBoard(seq))

        model.addAttribute("mode", "update")
        return "thymeleaf/insertBoard"
    }

    @PostMapping("/updateBoard/{seq}")
    fun updateBoard(@PathVariable seq: Int, board: Board): String {
        
        boardService.updateBoard(seq, board)

        return "redirect:/getBoardList"
    }

    @PostMapping("/deleteBoard/{seq}")
    fun deleteBoard(@PathVariable seq: Int): String {
        
        boardService.deleteBoard(seq)

        return "redirect:/getBoardList"
    }

    @GetMapping("/searchBoard")
    fun searchBoard(@RequestParam keyword: String, @RequestParam searchType: String,
                    model: Model): String {
        val boardList = searchService.search(searchType, keyword)

        model.addAttribute("boardList", boardList)

        return "thymeleaf/listBoard"
    }
}
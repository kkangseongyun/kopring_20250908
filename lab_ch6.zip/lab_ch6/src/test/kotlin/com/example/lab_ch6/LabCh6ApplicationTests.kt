package com.example.lab_ch6

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class LabCh6ApplicationTests {

	@Test
	fun contextLoads() {
	}

}

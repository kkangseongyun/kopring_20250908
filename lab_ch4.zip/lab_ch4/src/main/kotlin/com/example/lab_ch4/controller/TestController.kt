package com.example.lab_ch4.controller

import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.ModelAttribute
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController

@RestController
@RequestMapping("/api")
class TestController {

    //요청 정보를 담기 위한 dto
    data class ParamDto(val data1: Int, val data2: String, val data3: Boolean)

    //http://localhost:8080/api/test1/1/one?param1=10&paramData2=two&data1=20&data2=three&data3=true
    @GetMapping("/test1/{pathValue1}/{pathValue2}")
    fun test1(
        @PathVariable pathValue1: Int,
        @PathVariable("pathValue2") path2: String,
        @RequestParam param1: Int,
        @RequestParam("paramData2") param2: String,
        @ModelAttribute paramDto: ParamDto
    ): String {
        return """
            pathValue1: $pathValue1,
            pathValue2: $path2,
            param1: $param1,
            param2: $param2,
            dto : $paramDto
        """.trimIndent()
    }

    //request body 에 json 데이터가 넘어온다는 가정..
    //String 으로 받으면 json 이 평문 문자열로 받아진다..
    @PostMapping("/test2")
    fun test2(@RequestBody body: String): String {
        return body
    }

    @PostMapping("/test3")
    fun test3(@RequestBody body: ParamDto): String {
        return body.toString()
    }
}
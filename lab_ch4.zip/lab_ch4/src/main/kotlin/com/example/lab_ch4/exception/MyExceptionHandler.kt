package com.example.lab_ch4.exception

import org.springframework.http.ProblemDetail
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.ExceptionHandler
import org.springframework.web.bind.annotation.RestControllerAdvice

//모든 컨트롤러의 에러 처리 공통..
//RestControllerAdvice - 예외 advice 만을 목적으로 하지 않는다.. 데이터 바인딩..등
@RestControllerAdvice
class MyExceptionHandler {
    @ExceptionHandler(MyException::class)
    fun handleException(e: MyException): ResponseEntity<ProblemDetail> {
        return ResponseEntity.status(e.statusCode).body(e.body)
    }
    //여러개 선언이 가능하다..
    //예외 발생시에.. 타입으로 여러곳에 걸린다면 구체적인 예외가 우선순위가 높다..
}
package com.example.lab_ch4.validator

import jakarta.validation.Constraint
import jakarta.validation.Payload
import kotlin.reflect.KClass

//검증 조건이 필요한 곳에 선언하는 어노테이션...
//어느 위치에 들어갈 어노테이션인가?
@Target(AnnotationTarget.FIELD, AnnotationTarget.PROPERTY)
//어노테이션이 언제까지 유지되어야 하는지...
@Retention(AnnotationRetention.RUNTIME)
@MustBeDocumented
@Constraint(validatedBy = [MinStringLengthValidator::class])
annotation class MinStringLength(
    //annotation 을 이용하면서 추가적으로 설정해야 하는데이터. 마음껏..
    val value: Int,
    //아래는 검증 어노테이션이라면 필수..
    val message: String = "문자열의 길이가 {value} 이상이어야 합니다.",
    //group 정보를 지정하여.. 검증시에 특정 그룹의 검증만 되게 할 수 있다..
    val groups: Array<KClass<*>> = [],
    val payload: Array<KClass<out Payload>> = []//부가 정보..
)
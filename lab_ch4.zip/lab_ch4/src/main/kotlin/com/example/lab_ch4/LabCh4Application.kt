package com.example.lab_ch4

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class LabCh4Application

fun main(args: Array<String>) {
	runApplication<LabCh4Application>(*args)
}

package com.example.lab_ch4.validator

import jakarta.validation.ConstraintValidator
import jakarta.validation.ConstraintValidatorContext

//어노테이션이 추가된 데이터를 이용해 실제 검증 성공/실패 판단...
class MinStringLengthValidator: ConstraintValidator<MinStringLength, String?> {
    private var minLength: Int = 0

    //필수 오버라이드 대상은 아니다..
    //어노테이션에서 정보를 추출해 알고리즘에 이용한다면...
    override fun initialize(constraintAnnotation: MinStringLength) {
        minLength = constraintAnnotation.value
    }
    //필수 오버라이드 대상.. 검증을 위해 호출..
    override fun isValid(p0: String?, p1: ConstraintValidatorContext?): Boolean {
        if(p0 == null) return true
        return p0.length >= minLength
    }
}
package com.example.lab_ch4.exception

import org.springframework.http.HttpStatus
import org.springframework.http.ProblemDetail
import org.springframework.web.ErrorResponseException
import java.net.URI

//custom exception
//Exception 등 java 기본 ApI 를 상속받아 작성도 가능하기는 하지만..
//예외 정보를 표현하기 위한..ProblemDetail 이 내장된.. ErrorResponseException 상속..
class MyException(
    detail: String,
    cause: Throwable? = null
): ErrorResponseException(
    //상위에 ProblemDetail 있다.. 상위 생성자에 정보만..
    HttpStatus.BAD_REQUEST,
    ProblemDetail.forStatusAndDetail(HttpStatus.BAD_REQUEST, detail),
    cause
) {
    //원한다면.. 부가정보..
    init {
        body.title = "My Error..."
        body.type = URI.create("https://www.aaa.com")
    }
}
package com.example.lab_ch4

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class LabCh4ApplicationTests {

	@Test
	fun contextLoads() {
	}

}

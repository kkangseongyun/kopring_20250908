package com.example.lab_ch7

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class LabCh7ApplicationTests {

	@Test
	fun contextLoads() {
	}

}

package com.example.lab_ch7.config

import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration
import org.springframework.security.config.annotation.web.builders.HttpSecurity
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder
import org.springframework.security.crypto.password.PasswordEncoder
import org.springframework.security.web.SecurityFilterChain

@Configuration
@EnableWebSecurity
class SecurityConfig {
    //스프링에서 제공되는 암호화 알고리즘에 따른 여러 클래스중 하나..
    @Bean
    fun passwordEncoder(): PasswordEncoder = BCryptPasswordEncoder()

    @Bean
    fun filterChain(http: HttpSecurity): SecurityFilterChain {
        return http
            .authorizeHttpRequests {
                it.requestMatchers("/", "/getBoard", "/register", "/login").permitAll()
                it.requestMatchers("/deleteBoard/**").hasRole("ADMIN")
                it.anyRequest().authenticated()//인증만 되면 된다..
            }
            .formLogin {
                it.loginPage("/login")//security 가 로그인 화면을 띄울때 GET 방식으로 이 url 이용하라
                it.loginProcessingUrl("/login")//POST 방식으로 이 url 요청의 데이터로 로그인 처리하라
                it.defaultSuccessUrl("/")//로그인 성공시에.. 띄울 url
                it.failureUrl("/login?error=true")//실패시....
                it.usernameParameter("id")//POST 방식의 로그인 요청시 id 데이터 키...
                it.passwordParameter("password")
            }
            .logout {
                it.logoutUrl("/logout")//이 url 요청이 로그아웃 요청이다..
                it.logoutSuccessUrl("/")//로그아웃 처리후
            }
            .build()
    }

}
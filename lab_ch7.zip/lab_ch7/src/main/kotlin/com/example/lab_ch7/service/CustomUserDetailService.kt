package com.example.lab_ch7.service

import com.example.lab_ch7.persistence.UserRepository
import org.springframework.security.core.userdetails.User
import org.springframework.security.core.userdetails.UserDetails
import org.springframework.security.core.userdetails.UserDetailsService
import org.springframework.security.core.userdetails.UsernameNotFoundException
import org.springframework.stereotype.Service

//controller에서 유저 요청을 받아 직접 실행시킬 서비스가 아니라..
//spring security에 의해..login 요청이 들어왔을때 유저 정보를 구축하기 위해서 호출..
@Service
class CustomUserDetailService(
    private val userRepository: UserRepository
): UserDetailsService {//이 인터페이스를 구현한 서비스를 빈으로 등록하면.. security 가 자동 인지
    //인증 요청시 자동으로 호출된다.. 매개변수가 security 가 추출한 id 이다..
    //UserDetails - 유저 정보.. 적절하게 리턴만 시키면.. security 가 인증 처리하고.. 적절하게 정보 유지..
    override fun loadUserByUsername(username: String): UserDetails? {
        val user = userRepository.findById(username)
            .orElseThrow { UsernameNotFoundException("user not found") }

        return User.builder()
            .username(user.id)
            .password(user.password)
            .authorities("ROLE_${user.role}")
            .build()
    }
}
package com.example.lab_ch7.service


import com.example.lab_ch7.domain.Board
import com.example.lab_ch7.persistence.JPABoardRepository
import jakarta.transaction.Transactional
import org.springframework.stereotype.Service

@Service
class JPABoardService(
    private val boardRepository: JPABoardRepository
) {
    fun getBoard(seq: Int): Board {
        return boardRepository.findById(seq)
            .orElseThrow {
                RuntimeException("Board not found with seq : $seq")
            }
    }
    fun getBoardList(): List<Board> {
        return boardRepository.findAll()
    }
    fun insertBoard(board: Board){
        boardRepository.save(board)
    }
    fun updateBoard(seq: Int, board: Board){
        val existingBoard = boardRepository.findById(seq)
            .orElseThrow { RuntimeException("Board not found with seq: $seq") }

        existingBoard.title = board.title
        existingBoard.writer = board.writer
        existingBoard.content = board.content
        existingBoard.cnt = board.cnt

        boardRepository.save(existingBoard)
    }

    @Transactional
    fun deleteBoard(seq: Int){
        val board = boardRepository.findById(seq)
            .orElseThrow { RuntimeException("Board not found with seq: $seq") }


        boardRepository.delete(board)  // 엔티티 객체로 삭제
        boardRepository.flush()

    }
}
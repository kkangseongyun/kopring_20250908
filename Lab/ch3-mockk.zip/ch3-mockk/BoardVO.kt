package com.example.lab_ch3.domain

import java.util.Date

data class BoardVO(
    var seq: Int,
    var title: String,
    var writer: String,
    var content: String,
    var createDate: Date = Date(),
    var cnt: Int = 0
)
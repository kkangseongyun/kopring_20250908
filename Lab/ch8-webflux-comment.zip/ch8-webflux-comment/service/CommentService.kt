package com.example.lab_comment.service

import com.example.lab_comment.domain.Comment
import com.example.lab_comment.persistence.CommentRepository
import kotlinx.coroutines.flow.Flow
import org.springframework.stereotype.Service

@Service
class CommentService(
    private val commentRepository: CommentRepository
) {
    // 댓글 생성 (ID 자동 생성)
    suspend fun createComment(content: String, author: String, boardId: Long): Comment {
        val comment = Comment(content = content, author = author, boardId = boardId)

        val savedComment = commentRepository.save(comment)
        println("생성된 댓글 ID: ${savedComment.id}")
        return savedComment
    }

    // 게시글의 모든 댓글 조회 (Flow 반환)
    fun getCommentsByBoard(boardId: Long) {
        return commentRepository.findByBoardIdOrderByCreatedAtDesc(boardId)
    }

    // 게시글의 댓글 수 조회
    suspend fun getCommentsCount(boardId: Long): Long {
        return commentRepository.countByBoardId(boardId)
    }
}
package com.example.lab_comment.domain

import org.springframework.data.annotation.Id
import org.springframework.data.relational.core.mapping.Table
import java.time.LocalDateTime


data class Comment(

    val id: Long? = null,  
    val content: String,
    val author: String,
    val boardId: Long,
    val createdAt: LocalDateTime = LocalDateTime.now()
)
package com.example.lab_comment.dto

data class CreateCommentRequest(
    val content: String,
    val author: String,
    val boardId: Long
)
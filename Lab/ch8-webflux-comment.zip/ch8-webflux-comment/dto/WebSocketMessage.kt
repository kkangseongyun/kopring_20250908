package com.example.lab_comment.dto

data class MyWebSocketMessage(
    val type: String,
    val content: String? = null,
    val boardId: Long? = null,
    val username: String? = null
)
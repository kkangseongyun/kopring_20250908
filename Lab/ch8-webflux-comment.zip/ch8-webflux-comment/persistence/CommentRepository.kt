package com.example.lab_comment.persistence

import com.example.lab_comment.domain.Comment
import kotlinx.coroutines.flow.Flow
import org.springframework.data.r2dbc.repository.Query
import org.springframework.data.repository.kotlin.CoroutineCrudRepository
import org.springframework.data.repository.query.Param


interface CommentRepository  {
    // board_id로 댓글 조회 (생성일 내림차순)
    @Query("SELECT * FROM comments WHERE board_id = :boardId ORDER BY created_at DESC")
    fun findByBoardIdOrderByCreatedAtDesc(@Param("boardId") boardId: Long)

    // board_id로 댓글 수 조회
    @Query("SELECT COUNT(*) FROM comments WHERE board_id = :boardId")
    fun countByBoardId(@Param("boardId") boardId: Long): Long
}
package com.example.lab_ch7.dto

data class LoginRequest(
    val username: String,
    val password: String
)
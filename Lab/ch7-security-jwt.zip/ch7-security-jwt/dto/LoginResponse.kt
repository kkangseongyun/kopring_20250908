package com.example.lab_ch7.dto

data class LoginResponse(
    val token: String
)
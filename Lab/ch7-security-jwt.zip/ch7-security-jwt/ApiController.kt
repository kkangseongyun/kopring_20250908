package com.example.lab_ch7.controller

import com.example.lab_ch7.domain.Board
import com.example.lab_ch7.dto.LoginRequest
import com.example.lab_ch7.dto.LoginResponse
import com.example.lab_ch7.service.JPABoardService
import com.example.lab_ch7.jwt.JwtTokenProvider
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.security.core.userdetails.UserDetailsService
import org.springframework.security.crypto.password.PasswordEncoder
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController

@RestController
@RequestMapping("/api")
class ApiController(
    private val userDetailsService: UserDetailsService,
    private val passwordEncoder: PasswordEncoder,
    private val jwtTokenProvider: JwtTokenProvider,
    private val boardService: JPABoardService,
) {
    @PostMapping("/login")
    fun login(@RequestBody request: LoginRequest): ResponseEntity<LoginResponse> {

        
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build()
    }

    @RequestMapping("/getBoardList")
    fun getBoardList(): List<Board> {
        return boardService.getBoardList()

    }


}
package org.example.starter

import okhttp3.OkHttpClient
import org.slf4j.LoggerFactory
import org.springframework.boot.autoconfigure.AutoConfiguration
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty
import org.springframework.boot.context.properties.EnableConfigurationProperties
import org.springframework.context.annotation.Bean
import kotlin.math.log

//자동 설정을 위한 클래스..
//AutoConfiguration.import 에 등록해야..
@AutoConfiguration
@ConditionalOnClass(OkHttpClient::class)//빈으로 등록되는 조건 설정..
@ConditionalOnProperty(//property 설정 조건.. application.yml에 아래 설정이 있다면..
    prefix = "myteam.okhttp",
    name = ["enabled"],
    havingValue = "true",
    matchIfMissing = true
)
@EnableConfigurationProperties(OkHttpProperties::class)//application.yml의 property 값이 XXXProperties에 설정되게
class OkHttpAutoConfiguration {
    private val logger = LoggerFactory.getLogger(OkHttpAutoConfiguration::class.java)

    //@Bean 이 추가된 함수가 자동 호출되고.. 이 함수에서 리턴하는 객체가 ioc container에 빈으로 등록된다..
    @Bean
    @ConditionalOnMissingBean//이 함수에서 리턴하는 타입의 빈이 등록이 안되어 있다면..
    fun okHttpClientCustomizer(properties: OkHttpProperties): OkHttpClientCustomizer {
        logger.info("==> okHttpClientCustomizer")
        return OkHttpClientCustomizer(properties)
    }

    @Bean
    @ConditionalOnMissingBean
    fun okHttpClient(customizer: OkHttpClientCustomizer): OkHttpClient {
        logger.info("==> okHttpClient")
        return customizer.customize()
    }
//org.springframework.boot.autoconfigure.AutoConfiguration.imports
}

//배포...
//gradlew clean publishToMavenLocal

//C:\Users\student\.m2\repository\org\example
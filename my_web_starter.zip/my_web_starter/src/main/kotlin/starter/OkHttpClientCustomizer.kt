package org.example.starter

import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import org.slf4j.LoggerFactory


class OkHttpClientCustomizer(
    private val properties: OkHttpProperties
) {
    private val logger = LoggerFactory.getLogger(OkHttpClientCustomizer::class.java)

    fun customize(): OkHttpClient {
        val builder = OkHttpClient.Builder()
            .connectTimeout(properties.connectTimeout)
            .readTimeout(properties.readTimeout)
            .writeTimeout(properties.writeTimeout)


        // 로깅 인터셉터 추가
        if (properties.logging.enabled) {
            val loggingInterceptor = HttpLoggingInterceptor { message ->
                logger.info("OkHttp: $message")
            }

            loggingInterceptor.level = when (properties.logging.level.uppercase()) {
                "NONE" -> HttpLoggingInterceptor.Level.NONE
                "BASIC" -> HttpLoggingInterceptor.Level.BASIC
                "HEADERS" -> HttpLoggingInterceptor.Level.HEADERS
                "BODY" -> HttpLoggingInterceptor.Level.BODY
                else -> HttpLoggingInterceptor.Level.BASIC
            }

            builder.addInterceptor(loggingInterceptor)
        }

        return builder.build()
    }
}
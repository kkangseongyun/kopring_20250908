plugins {
    kotlin("jvm") version "2.2.0"

    //라이브러리만 묶어서 제공할 때는 필요 없다.. 순수 자바 프로젝트로..
    //자동 설정 기능을 제공하려면.. 스프링과 관련된 어노테이션을 사용해야 해서..
    kotlin("plugin.spring") version "2.2.0"

    `maven-publish`
}

group = "org.example"
version = "1.0-SNAPSHOT"

repositories {
    mavenCentral()
}

dependencies {
//    testImplementation(kotlin("test"))
    //아래의 라이브러리를 묶어서.. starter로 제공한다는 가정..
    api("com.squareup.okhttp3:okhttp:4.12.0")
    api("com.squareup.okhttp3:logging-interceptor:4.12.0")


    // BOM import로 버전 관리
    implementation(platform("org.springframework.boot:spring-boot-dependencies:3.5.3"))
    api("org.springframework.boot:spring-boot-starter")
}

tasks.test {
    useJUnitPlatform()
}
kotlin {
    jvmToolchain(17)
}

publishing {
    publications {
        create<MavenPublication>("maven") {
            //from(components["java"])는 Java 플러그인이 생성한 JAR 파일과 의존성 정보를 자동으로 Maven publication에 포함
            from(components["java"])
        }
    }
}
package com.example.lab_ch3

import com.example.lab_ch3.domain.BoardVO
import com.example.lab_ch3.service.BoardService
import com.ninjasquad.springmockk.MockkBean
import io.mockk.every
import org.junit.jupiter.api.Test
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.boot.test.web.client.TestRestTemplate
import org.springframework.boot.test.web.client.getForObject
import kotlin.test.assertEquals

//E2E 테스트를 하고자 한다.. 톰켓 서버 구동시켜야 한다..
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class LabCh3ApplicationTests {

    //가상의 브라우저...
    @Autowired
    lateinit var restTemplate: TestRestTemplate

    //특정 빈을 대체하기 위한 가상의 객체...
    //BoardService 를 대체시킴으로.. 테스트시에 BoardService 의 함수가 실행되면 안된다..
    @MockkBean
    lateinit var boardService: BoardService

	@Test
	fun contextLoads() {
        val board = BoardVO(seq = 1, title = "테스트", writer = "홍길동", content = "내용")

        //mock 객체에 가상의 작업을 등록한다..
        //{ } 패턴의 요청이 들어오면.. 가상의 객체는 board를 리턴한다..
        every { boardService.getBoard(1) } returns board

        //브라우저 mock 에게 일을 시켜서 테스트 한다..
        val result = restTemplate.getForObject<BoardVO>("/getBoard?seq=1")
        assertEquals("홍길동", result?.writer)
	}

}

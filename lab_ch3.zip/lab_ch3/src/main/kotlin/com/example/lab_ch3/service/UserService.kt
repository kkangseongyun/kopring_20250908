package com.example.lab_ch3.service

import com.example.lab_ch3.domain.User
import com.example.lab_ch3.repository.UserRepository
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service

//repository 를 이용해 부가적인 B/L 담당..
//아래의 어노테이션을 추가하는 것만으로.. 자동으로 인지.. 객체 생성.. spring container(Ioc)에 등록
@Service
class UserService {
    //필요한 Repository 를 주입 받아서..
    //타입을 보고.. spring container에 등록된 객체(빈-Bean)객체를 주입
    @Autowired
    lateinit var userRepository: UserRepository

    fun getAllUser(): List<User>{
        return userRepository.getAllUser()
    }
}
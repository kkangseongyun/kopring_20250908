package com.example.lab_ch3.controller

import com.example.lab_ch3.domain.User
import com.example.lab_ch3.property.AppProperties
import com.example.lab_ch3.service.UserService
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Value
import org.springframework.core.env.Environment
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.RestController

//client http request 시에 spring web 모듈에 의해 실행될 클래스...
@RestController
class UserController(
    //생성자 주입..spring container의 bean 을 주입받는 방법.. @Autowired 도 있고 생성자 주입도있고
    val userService: UserService
) {
    init {
        println("==> UserController")
    }

    //http request 시에 호출될 함수.. url?
    @GetMapping("/users")//http://~~~~/users - GET, 리턴 시킨 객체의 내용이 json 으로 만들어져 response
    fun getAllUser(): List<User>{
        return userService.getAllUser()
    }

    //custom property 이용 테스트...........................
    //${ } 표현식은 스프링 전체에서 사용할 수 있는 표현식 (SpEL) 이다.. 주로 Thymeleaf에서 많이 사용한다..
    @Value("\${app.name}")
    lateinit var  appName: String
    //선언하면서.. 기본값 설정 가능하다..
    @Value("\${app.feature.enabled:false}")
    var featureEnabled: Boolean = false

    @Autowired
    lateinit var appProperties: AppProperties

    @Autowired
    lateinit var env: Environment//applicaito.yml 의 모든 내용이 등록되는 곳..

    @GetMapping("/properties")
    fun test1(): String {
        println("""
            @Value
            $appName
            $featureEnabled
        """.trimIndent())

        println("""
            @ConfigurationProperties
            ${appProperties.name}
            ${appProperties.author.name} -  ${appProperties.author.email}
        """.trimIndent())

        println("""
            Enviroment
            ${env.getProperty("app.name")}
            ${env.getProperty("app.feature.maxUsers", Int::class.java, 100)}
        """.trimIndent())

        return "test ok"
    }
}















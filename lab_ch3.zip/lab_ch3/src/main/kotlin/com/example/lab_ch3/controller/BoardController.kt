package com.example.lab_ch3.controller

import com.example.lab_ch3.domain.BoardVO
import com.example.lab_ch3.service.BoardService
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.RestController

@RestController
class BoardController {
    init {
        println("==> BoardController")
    }

    @Autowired
    lateinit var boardService: BoardService

    @GetMapping("/getBoard")
    fun getBoard(seq: Int): BoardVO {
        //테스트할 때는 실행되지 않아야 하는 코드로 가정..
        return boardService.getBoard(seq)
    }
}
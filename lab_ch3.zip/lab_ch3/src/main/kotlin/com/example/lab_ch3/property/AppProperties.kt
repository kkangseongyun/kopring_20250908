package com.example.lab_ch3.property

import org.springframework.boot.context.properties.ConfigurationProperties

//application.yml 에 설정된 정보를 가지는 클래스.. 객체...
//아래의 어노테이션은 설정 매핑 방법을 명시한 것이다..
//spring 의 빈으로 등록해서.. 여러곳에서 이용하게 해주어야 한다..
//@SpringBootApplicaiton 클래스에 어노테이션을 추가해서.. 빈으로 등록하게 해주어야..
@ConfigurationProperties(prefix = "app")
data class AppProperties(
    val name: String = "",
    val version: String = "",
    val author: Author = Author(),
    val feature: Feature = Feature()
){
    data class Author(
        val name: String = "",
        val email: String = ""
    )
    data class Feature(
        val enabled: Boolean = false,
        val maxUsers: Int = 0
    )
}
package com.example.lab_ch3.runner

import org.springframework.boot.ApplicationArguments
import org.springframework.boot.ApplicationRunner
import org.springframework.stereotype.Component

//애플리케이션이 구동이 완료되자 마자.. 클라이언트 요청이 없어도 최초에 한번
//실행시켜야할 업무가 있다.. 가정..
@Component
class MyApplicationRunner: ApplicationRunner {
    override fun run(args: ApplicationArguments?) {
        println("애플리케이션이 시작 후 자동으로 실행됨....")
    }
}
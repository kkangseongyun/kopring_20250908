package com.example.lab_ch3

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class LabCh3Application

fun main(args: Array<String>) {
	runApplication<LabCh3Application>(*args)
}

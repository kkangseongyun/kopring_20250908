package com.example.lab_ch3

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.context.properties.ConfigurationPropertiesScan
import org.springframework.boot.runApplication

@SpringBootApplication
//애플리케이션 내의 모든 @ConfigurationProperties 클래스를 찾아내서.. 빈으로 등록하라..
@ConfigurationPropertiesScan
class LabCh3Application

fun main(args: Array<String>) {
	runApplication<LabCh3Application>(*args)
}

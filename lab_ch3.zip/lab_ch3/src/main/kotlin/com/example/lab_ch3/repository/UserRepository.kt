package com.example.lab_ch3.repository

import com.example.lab_ch3.domain.User
import org.springframework.stereotype.Repository

//dbms 가정...
//아래의 어노테이션을 추가하는 것만으로.. 자동으로 인지.. 객체 생성.. spring container(Ioc)에 등록
@Repository
class UserRepository {
    fun getAllUser(): List<User>{
        //db 에서 select 한 데이터라는 가정..
        //나중에 mybatis, jpa 등의 기법을 적용해서 실제 dbms 되게..
        val users = listOf<User>(
            User("1", "kim", "a@a.com"),
            User("2", "lee", "b@b.com")
        )
        return users
    }
}
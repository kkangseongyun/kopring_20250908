package com.example.lab_comment.config

import com.example.lab_comment.handler.CommentWebSocketHandler
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration
import org.springframework.web.reactive.HandlerMapping
import org.springframework.web.reactive.handler.SimpleUrlHandlerMapping
import org.springframework.web.reactive.socket.WebSocketHandler
import org.springframework.web.reactive.socket.server.support.WebSocketHandlerAdapter

@Configuration
class WebSocketConfig(
    private val socketHandler: CommentWebSocketHandler
) {
    //일반 url 요청은 Controller 로 들어가서 처리되게..
    //websocket 클라이언트 요청을 처리할 handler를 하나 더 만들어서 등록..
    @Bean
    fun handleMapping(): HandlerMapping {
        val map = mapOf<String, WebSocketHandler>(
            "/ws/comments/*" to socketHandler
        )
        return SimpleUrlHandlerMapping(map, -1)
    }
    //위 함수에서 등록한 핸들러를 실행시켜 주는 역할.. 아래처럼 등록만 하면 된다..
    @Bean
    fun handleAdapter(): WebSocketHandlerAdapter {
        return WebSocketHandlerAdapter()
    }
}
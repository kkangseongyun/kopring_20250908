package com.example.lab_comment

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class LabCommentApplication

fun main(args: Array<String>) {
	runApplication<LabCommentApplication>(*args)
}

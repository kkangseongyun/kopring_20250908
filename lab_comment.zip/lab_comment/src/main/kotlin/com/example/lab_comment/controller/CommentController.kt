package com.example.lab_comment.controller

import com.example.lab_comment.domain.Comment
import com.example.lab_comment.dto.CreateCommentRequest
import com.example.lab_comment.service.CommentService
import kotlinx.coroutines.flow.Flow
import org.springframework.web.bind.annotation.CrossOrigin
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController



@RestController
@RequestMapping("/api/comments")
class CommentController(
    private val commentService: CommentService
) {
    // 게시글별 댓글 조회 (Flow 반환)
    @GetMapping("/board/{boardId}")
    fun getComments(@PathVariable boardId: Long) {
        return commentService.getCommentsByBoard(boardId)
    }

    // 댓글 수 조회
    @GetMapping("/board/{boardId}/count")
    suspend fun getCommentsCount(@PathVariable boardId: Long): Long {
        return commentService.getCommentsCount(boardId)
    }

    // 댓글 생성 (REST API용)
    @PostMapping
    suspend fun createComment(@RequestBody request: CreateCommentRequest): Comment {
        return commentService.createComment(
            request.content,
            request.author,
            request.boardId
        )
    }
}
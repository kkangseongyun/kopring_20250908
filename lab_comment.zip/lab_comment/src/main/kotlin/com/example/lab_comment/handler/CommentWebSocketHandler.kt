package com.example.lab_comment.handler

import com.example.lab_comment.dto.MyWebSocketMessage
import com.example.lab_comment.service.CommentService
import com.fasterxml.jackson.databind.ObjectMapper
import kotlinx.coroutines.reactor.mono
import org.springframework.stereotype.Component
import org.springframework.web.reactive.socket.WebSocketHandler
import org.springframework.web.reactive.socket.WebSocketMessage
import org.springframework.web.reactive.socket.WebSocketSession
import reactor.core.publisher.Mono
import reactor.core.publisher.Sinks
import java.time.Duration
import java.util.concurrent.ConcurrentHashMap
import java.util.logging.Logger



@Component
class CommentWebSocketHandler(
    private val commentService: CommentService,
    private val objectMapper: ObjectMapper
) : WebSocketHandler {

    private val logger = Logger.getLogger(CommentWebSocketHandler::class.java.name)

    private val boardSinks = ConcurrentHashMap<Long, Sinks.Many<String>>()

    private val sessionInfo = ConcurrentHashMap<String, SessionData>()

    data class SessionData(
        val boardId: Long,
        val username: String,
        val session: WebSocketSession
    )

    override fun handle(session: WebSocketSession): Mono<Void> {

        val boardId = extractBoardId(session)
        val username = extractUsername(session)

        logger.info("WebSocket 연결 요청 - BoardId: $boardId, Username: $username")

        if (boardId == null || username == null) {
            logger.warning("잘못된 연결 요청 - BoardId: $boardId, Username: $username")
            return session.close(org.springframework.web.reactive.socket.CloseStatus.BAD_DATA)
        }

        sessionInfo[session.id] = SessionData(boardId, username, session)

        val sink = boardSinks.computeIfAbsent(boardId) {
            logger.info("새로운 보드 싱크 생성 - BoardId: $boardId")
            Sinks.many().multicast().onBackpressureBuffer()
        }

        // 연결 성공 메시지 전송
        val welcomeMessage = mapOf(
            "type" to "CONNECTION_SUCCESS",
            "message" to "실시간 댓글 서비스에 연결되었습니다."
        )
        sink.tryEmitNext(objectMapper.writeValueAsString(welcomeMessage))

        // 메시지 수신 처리
        val input = session.receive()
            .timeout(Duration.ofMinutes(30)) // 30분 타임아웃
            .map(WebSocketMessage::getPayloadAsText)
            .flatMap { payload ->
                handleIncomingMessage(payload, boardId, username, sink)
            }
            .doOnError { error ->
                logger.severe("메시지 수신 처리 중 오류 발생: ${error.message}")
            }
            .onErrorResume { error ->
                // 오류 발생 시 클라이언트에게 오류 메시지 전송
                val errorMessage = mapOf(
                    "type" to "ERROR",
                    "message" to "서버 오류가 발생했습니다: ${error.message}"
                )
                sink.tryEmitNext(objectMapper.writeValueAsString(errorMessage))
                Mono.empty()
            }
            .then()

        // 메시지 전송 처리
        val output = session.send(
            sink.asFlux()
                .map(session::textMessage)
                .doOnNext { message -> 
                    logger.fine("메시지 전송: ${message.payloadAsText}")
                }
                .onErrorResume { error ->
                    logger.severe("메시지 전송 중 오류: ${error.message}")
                    reactor.core.publisher.Flux.empty()
                }
        )

        return Mono.zip(input, output)
            .doOnTerminate {
                cleanupSession(session.id, boardId)
            }
            .doOnCancel {
                logger.info("WebSocket 연결이 취소되었습니다 - SessionId: ${session.id}")
                cleanupSession(session.id, boardId)
            }
            .then()
    }

    private fun handleIncomingMessage(
        payload: String,
        boardId: Long,
        username: String,
        sink: Sinks.Many<String>
    ): Mono<Void> {
        return mono {
            try {
                logger.info("메시지 수신: $payload")
                val message = objectMapper.readValue(payload, MyWebSocketMessage::class.java)

                when (message.type) {
                    "CREATE_COMMENT" -> {
                        if (message.content.isNullOrBlank()) {
                            val errorResponse = mapOf(
                                "type" to "ERROR",
                                "message" to "댓글 내용이 비어있습니다."
                            )
                            sink.tryEmitNext(objectMapper.writeValueAsString(errorResponse))
                            return@mono
                        }

                        // 코루틴으로 댓글 생성
                        val savedComment = commentService.createComment(
                            message.content,
                            username,
                            boardId
                        )

                        logger.info("댓글 생성 완료 - ID: ${savedComment.id}")

                        // 새 댓글을 모든 클라이언트에게 브로드캐스트
                        val response = mapOf(
                            "type" to "NEW_COMMENT",
                            "data" to mapOf(
                                "id" to savedComment.id,
                                "content" to savedComment.content,
                                "author" to savedComment.author,
                                "createdAt" to savedComment.createdAt.toString()
                            )
                        )

                        val emitResult = sink.tryEmitNext(objectMapper.writeValueAsString(response))
                        if (emitResult.isFailure) {
                            logger.warning("메시지 브로드캐스트 실패: $emitResult")
                        }
                    }

                    "USER_DISCONNECT" -> {
                        logger.info("사용자 연결 종료 메시지 수신 - Username: $username")
                        // 특별한 처리가 필요하다면 여기에 추가
                    }

                    "PING" -> {
                        // 핑-퐁 메커니즘
                        val pongResponse = mapOf(
                            "type" to "PONG",
                            "timestamp" to System.currentTimeMillis()
                        )
                        sink.tryEmitNext(objectMapper.writeValueAsString(pongResponse))
                    }

                    else -> {
                        logger.warning("지원하지 않는 메시지 타입: ${message.type}")
                        val errorResponse = mapOf(
                            "type" to "ERROR",
                            "message" to "지원하지 않는 메시지 타입입니다: ${message.type}"
                        )
                        sink.tryEmitNext(objectMapper.writeValueAsString(errorResponse))
                    }
                }
            } catch (e: Exception) {
                logger.severe("메시지 처리 중 오류 발생: ${e.message}")
                val errorResponse = mapOf(
                    "type" to "ERROR",
                    "message" to "메시지 처리 중 오류가 발생했습니다: ${e.message}"
                )
                sink.tryEmitNext(objectMapper.writeValueAsString(errorResponse))
            }
        }.then()
    }

    private fun cleanupSession(sessionId: String, boardId: Long) {
        logger.info("세션 정리 시작 - SessionId: $sessionId, BoardId: $boardId")

        // 세션 정보 제거
        sessionInfo.remove(sessionId)

        // 해당 보드에 연결된 세션이 없으면 싱크 정리
        val hasActiveSessions = sessionInfo.values.any { it.boardId == boardId }
        if (!hasActiveSessions) {
            boardSinks.remove(boardId)?.let { sink ->
                logger.info("보드 싱크 정리 완료 - BoardId: $boardId")
                try {
                    sink.tryEmitComplete()
                } catch (e: Exception) {
                    logger.warning("싱크 완료 처리 중 오류: ${e.message}")
                }
            }
        }

        logger.info("세션 정리 완료 - 활성 세션 수: ${sessionInfo.size}")
    }

    private fun extractBoardId(session: WebSocketSession): Long? {
        return try {
            session.handshakeInfo.uri.path.split("/").lastOrNull()?.toLongOrNull()
        } catch (e: Exception) {
            logger.warning("BoardId 추출 실패: ${e.message}")
            null
        }
    }

    private fun extractUsername(session: WebSocketSession): String? {
        return try {
            session.handshakeInfo.uri.query?.split("&")
                ?.find { it.startsWith("user=") }
                ?.substringAfter("user=")
                ?.let { java.net.URLDecoder.decode(it, "UTF-8") }
        } catch (e: Exception) {
            logger.warning("Username 추출 실패: ${e.message}")
            null
        }
    }
}
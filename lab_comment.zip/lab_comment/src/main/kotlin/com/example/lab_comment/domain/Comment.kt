package com.example.lab_comment.domain

import org.springframework.data.annotation.Id
import org.springframework.data.relational.core.mapping.Table
import java.time.LocalDateTime

//r2dbc entity 클래스...
//자동으로 테이블이 만들어지지는 않는다.. resources/schema.sql 에 담아놓으면 자동
//실행은 된다..
@Table("comments")
data class Comment(
    //null이면 데이터베이스에 따라 선택..
    //직접 값 주입 가능..
    @Id
    val id: Long? = null,  
    val content: String,
    val author: String,
    val boardId: Long,
    val createdAt: LocalDateTime = LocalDateTime.now()
)
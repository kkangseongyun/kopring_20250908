package com.example.lab_comment

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class LabCommentApplicationTests {

	@Test
	fun contextLoads() {
	}

}
